add_drv -v -n -m "* 0600 root sys" -i '"pccard101,589" "pccard101,562,0"' pcelx
sync
