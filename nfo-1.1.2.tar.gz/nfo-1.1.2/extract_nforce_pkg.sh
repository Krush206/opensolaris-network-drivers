#! /bin/csh -vf
set path = (/usr/xpg4/bin /bin /usr/bin)
#
./NFORCE-Linux-x86-1.0-*-pkg1.run --extract-only
./NFORCE-Linux-x86_64-1.0-*-pkg1.run --extract-only
